import java.util.ArrayList;


public class Main {
    public static void main(String[] args) {

        ListaEncadeada lista = new ListaEncadeada();

        lista.inserir(new Pessoa("Ana", 20));
        lista.inserir(new Pessoa("Bruno", 25));
        lista.inserir(new Pessoa("Carlos", 30));

        System.out.println("Lista de pessoas:");
        lista.percorrer();

        System.out.println("\nRemovendo Bruno...");
        lista.remover("Bruno");
        lista.percorrer();

        System.out.println("\nBuscando Ana:");
        Pessoa p = lista.buscar("Ana");
        if (p != null) {
            System.out.println(p);
        } else {
            System.out.println("Pessoa não encontrada");
        }
    }
}
