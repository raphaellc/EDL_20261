
 public class ListaEncadeada {
     
     class No {
         Pessoa pessoa;
         No proximo;
     
     
      public No (Pessoa pessoa)  {
            this.pessoa= pessoa;
            this.proximo = null;
      }
      
     }
     
     private No inicio;
     
     public ListaEncadeada() {
         inicio = null;
     }
      
      public void inserir (Pessoa pessoa) {
          No novo = new No (pessoa);
          
          if (inicio==null) {
              inicio = novo;
          }
          else {
              No atual = inicio;
              while (atual.proximo != null) {
                  atual = atual.proximo;
              }
              atual.proximo = novo;
          }
      }
      
      public void remover (String nome) {
          if (inicio == null) return;
          
          if (inicio.pessoa.getNome().equals(nome)) {
          
          inicio = inicio.proximo;
          return;
          
      }
      
      No atual = inicio;
      No anterior = null;
      
      while (atual != null && !atual.pessoa.getNome().equals(nome)) {
          anterior = atual;
          atual = atual.proximo;
      }
      }
      
     public Pessoa buscar(String nome) {
        No atual = inicio;

        while (atual != null) {
            if (atual.pessoa.getNome().equals(nome)) {
                return atual.pessoa;
            }
            atual = atual.proximo;
        }

        return null;
    }

    public void percorrer() {
        No atual = inicio;

        while (atual != null) {
            System.out.println(atual.pessoa);
            atual = atual.proximo;
        }
    }


      
 }