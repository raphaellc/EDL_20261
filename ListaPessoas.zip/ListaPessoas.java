import java.util.ArrayList;

public class ListaPessoas {
    
    private ArrayList<Pessoa> pessoas;
    
    public ListaPessoas () {
    pessoas = new ArrayList <>();
    }
    
    
    
    
    public void remover (String nome) {
        for ( Pessoa p : pessoas) {
            if (p.getNome().equals(nome)) {
                pessoas.remove(p);
            }
            else {
                return;
            }
        }
    }
    
    public void percorrer() {
        for (Pessoa p : pessoas) {
            System.out.println(p);
        }
    }
    
}